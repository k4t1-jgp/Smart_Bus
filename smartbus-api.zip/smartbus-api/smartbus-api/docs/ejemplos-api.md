# Ejemplos para probar la API (Postman)

En Postman: método y URL como se indica, pestaña **Body → raw → JSON**.
**Sigan este orden**, porque unas cosas dependen de otras (los números `1`, `2`... son los `id`
que devuelve cada respuesta; si su base ya tenía datos, usen los ids reales).

Las horas se escriben `"HH:mm"` y las fechas `"AAAA-MM-DD"`.

## 1. Datos base

**POST** `/api/roles`
```json
{ "nombre": "Administrador", "descripcion": "Gestión general del sistema" }
```

**POST** `/api/usuarios`
```json
{ "nombreUsuario": "admin", "contrasena": "admin123", "rolId": 1 }
```

**POST** `/api/auth/login`
```json
{ "nombreUsuario": "admin", "contrasena": "admin123" }
```

**POST** `/api/jornadas`
```json
{ "nombre": "Matutina", "horarioInicio": "07:00", "horarioFin": "12:30" }
```

**POST** `/api/vehiculos`
```json
{ "placa": "P-123ABC", "marca": "Toyota", "modelo": "Coaster", "color": "Amarillo",
  "anio": 2020, "capacidad": 2, "verificacion": "Vigente 2026" }
```
(La capacidad es 2 a propósito, para probar fácil que no se puede pasar del límite.)

**POST** `/api/pilotos`
```json
{ "nombre": "Carlos Pérez", "telefono": "55551234", "numeroLicencia": "LIC-0001",
  "tipoLicencia": "B", "fechaNacimiento": "1985-04-12", "fechaVencimientoLicencia": "2028-12-31" }
```

**POST** `/api/paradas`
```json
{ "nombre": "Parada Central", "ubicacion": "Parque central, Morales" }
```
Cree una segunda parada cambiando el nombre y la ubicación.

## 2. Armar y activar una ruta

**POST** `/api/rutas` (queda **inactiva**)
```json
{ "nombre": "Ruta Norte", "recorrido": "Centro - Colegio", "horarioSalida": "06:00",
  "horarioLlegada": "07:00", "jornadaId": 1, "vehiculoId": 1, "pilotoId": 1 }
```

**PUT** `/api/rutas/1/activar` → **falla** con 400: "La ruta debe tener al menos una parada..."

**POST** `/api/ruta-paradas`
```json
{ "rutaId": 1, "paradaId": 1, "orden": 1 }
```

**PUT** `/api/rutas/1/activar` → ahora **funciona** (`"estado": true`).

## 3. Estudiantes, encargados y asignaciones

**POST** `/api/estudiantes`
```json
{ "carne": "2026-001", "nombre": "Ana López", "grado": "5to Primaria",
  "jornada": "Matutina", "direccion": "Barrio El Centro" }
```
Cree dos o tres estudiantes más con otros carnés.

**POST** `/api/encargados`
```json
{ "nombre": "María de López", "telefono": "44445555", "correo": "maria@correo.com",
  "direccion": "Barrio El Centro" }
```

**POST** `/api/estudiante-encargados`
```json
{ "estudianteId": 1, "encargadoId": 1, "tipoEncargado": "Principal", "parentesco": "Madre" }
```

**POST** `/api/asignaciones`
```json
{ "estudianteId": 1, "rutaId": 1, "paradaId": 1 }
```

Pruebas de reglas (todas deben responder 400 con un mensaje claro):
- Repetir la misma asignación → "ya tiene una ruta activa en la jornada...".
- Asignar al estudiante 2 y luego al 3 → el 3 falla por **capacidad** (el bus solo admite 2).
- Usar una parada que no está en la ruta → "no pertenece a la ruta".

## 4. Pagos

**POST** `/api/pagos`
```json
{ "estudianteId": 1, "monto": 250.00, "mes": 9, "anio": 2026 }
```
Repetirlo → 400 "ya tiene un pago vigente para 9/2026".

**GET** `/api/pagos/pendientes?mes=9&anio=2026` → estudiantes con transporte que no han pagado.

**DELETE** `/api/pagos/1` → anula el pago (ya no cuenta como pagado).

## 5. Mantenimiento

**POST** `/api/mantenimientos` → **falla** mientras el vehículo esté en una ruta activa:
```json
{ "vehiculoId": 1, "tipo": "Preventivo", "detalle": "Cambio de aceite y frenos", "costo": 850.00 }
```
Primero **DELETE** `/api/rutas/1` (desactiva la ruta) y vuelva a intentarlo: ahora sí se registra.
Luego **PUT** `/api/rutas/1/activar` → falla: "el vehículo ... está en mantenimiento".
Al terminar: **PUT** `/api/mantenimientos/1/finalizar`.

## 6. Consultas y panel

- **GET** `/api/estudiantes/buscar?carne=2026`
- **GET** `/api/vehiculos/disponibles`
- **GET** `/api/asignaciones?rutaId=1`
- **GET** `/api/ruta-paradas?rutaId=1`
- **GET** `/api/dashboard`

Formato de los errores:
```json
{ "estado": 400, "error": "Bad Request", "mensaje": "La ruta debe tener al menos una parada antes de activarse" }
```
