# SmartBus Control – API (Spring Boot)

Sistema escolar de transporte del curso **Programación II – UMG**.
Es una **API REST** hecha con **Spring Boot 4 + Java 17 + MySQL**, con el mismo estilo del proyecto de
referencia `library-api` (capas modelo → repositorio → servicio → controlador, y DTOs), pero con las
14 tablas y las reglas del negocio del acta de constitución.

> Todo el código está comentado en español. Si algo no se entiende, empiece por la sección
> **"Cómo viaja una petición"**, que explica el recorrido completo de un ejemplo.

---

## 1. Cómo ejecutarlo

1. Tener instalado **JDK 17 o superior** y **MySQL** encendido (puerto 3306).
2. Abrir la carpeta `smartbus-api` en **IntelliJ IDEA** (*File → Open* y elegir el `pom.xml`).
   IntelliJ descarga solo las librerías de Maven.
3. Revisar `src/main/resources/application.properties` y poner **su usuario y contraseña de MySQL**.
4. Ejecutar la clase `SmartbusApiApplication` (botón ▶).
5. Al arrancar, Hibernate **crea la base `smart_bus` y las 14 tablas solas**. La API queda en
   `http://localhost:8080`.
6. Abrir **http://localhost:8080** en el navegador. La primera vez aparece el botón *Crear administrador*,
   que crea el usuario admin y los cinco roles del acta.
7. (Opcional) Probar la API sola con **Postman** siguiendo `docs/ejemplos-api.md`.

> **Importante:** use una base de datos NUEVA. No cargue encima el script SQL de la tercera entrega,
> porque ahí `estado` es texto ("Activo") y en este proyecto es verdadero/falso.

---

## 2. Estructura del proyecto

```
src/main/java/com/smartbus/smartbusapi/
├── SmartbusApiApplication.java   ← clase que arranca todo
├── model/        ← ENTIDADES: cada clase = una tabla (14 clases)
├── dto/          ← forma de los JSON que llegan y salen
├── repository/   ← habla con la base de datos (consultas)
├── service/      ← LÓGICA y reglas del negocio
├── controller/   ← recibe las peticiones HTTP
├── exception/    ← errores personalizados y su conversión a JSON
├── config/       ← configuración (encriptación de contraseñas)
└── util/         ← validaciones reutilizables
```

## 3. Las capas (la idea más importante)

| Capa | Pregunta que responde | Ejemplo |
|---|---|---|
| **Controller** | ¿Qué URL y qué método HTTP llegó? | `POST /api/estudiantes` |
| **Service** | ¿Se puede hacer esto? ¿Qué reglas aplican? | ¿Ya tiene ruta en esa jornada? |
| **Repository** | ¿Cómo lo guardo o lo busco en MySQL? | `save()`, `findById()` |
| **Model** | ¿Cómo es un dato y a qué tabla pertenece? | clase `Estudiante` → tabla `estudiante` |
| **DTO** | ¿Qué datos manda el cliente? | `{"carne": "2026-001", ...}` |

### Cómo viaja una petición (ejemplo: asignar un estudiante a una ruta)

1. Postman envía `POST /api/asignaciones` con `{"estudianteId":1,"rutaId":2,"paradaId":3}`.
2. **`AsignacionController`** recibe el JSON y lo convierte en un `AsignacionDto`. Llama al servicio.
3. **`AsignacionService`** busca el estudiante, la ruta y la parada (usando los repositorios) y aplica las
   reglas: ruta activa, parada de esa ruta, una ruta por jornada, capacidad del bus.
4. Si algo falla lanza una `ReglaNegocioException`; **`ManejadorGlobalExcepciones`** la convierte en un JSON
   de error legible (`400`) con el mensaje.
5. Si todo está bien, `AsignacionRepository.save(...)` guarda en MySQL y el controlador responde `201 Created`
   con la asignación en JSON.

### Anotaciones más usadas (glosario)

| Anotación | Significado |
|---|---|
| `@Entity` / `@Table` | Esta clase es una tabla de la base de datos |
| `@Id` / `@GeneratedValue` | Llave primaria autoincremental |
| `@Column` | Configura una columna (nombre, obligatoria, única) |
| `@ManyToOne` / `@JoinColumn` | Relación "muchos a uno" con llave foránea |
| `@RestController` | Clase que responde peticiones web en JSON |
| `@RequestMapping("/api/...")` | URL base del controlador |
| `@GetMapping`, `@PostMapping`, `@PutMapping`, `@DeleteMapping` | Método HTTP de cada función |
| `@PathVariable` | Toma un valor de la URL (`/estudiantes/5` → id = 5) |
| `@RequestBody` | Toma el JSON del cuerpo de la petición |
| `@RequestParam` | Toma un parámetro de la URL (`?carne=123`) |
| `@Service` | Clase de lógica; Spring la crea y la entrega donde se necesite |
| `@Bean` / `@Configuration` | Objeto o configuración que Spring administra |
| `@RestControllerAdvice` | Atrapa errores de todos los controladores |

---

## 4. Módulos y endpoints

Todas las rutas empiezan con `http://localhost:8080`. Los módulos con CRUD estándar tienen
`GET /`, `GET /{id}`, `POST /`, `PUT /{id}` y `DELETE /{id}` (el DELETE **desactiva**, no borra).

| Módulo (acta) | Ruta base | Extras |
|---|---|---|
| Roles | `/api/roles` | |
| Usuarios | `/api/usuarios` | La contraseña se encripta y nunca se devuelve |
| Inicio de sesión | `/api/auth/login` | `POST` con `nombreUsuario` y `contrasena` |
| Estudiantes | `/api/estudiantes` | `GET /buscar?carne=` |
| Encargados | `/api/encargados` | |
| Estudiante–Encargado | `/api/estudiante-encargados` | Aquí va el parentesco (DELETE sí borra la unión) |
| Pilotos | `/api/pilotos` | |
| Vehículos | `/api/vehiculos` | `GET /disponibles` |
| Jornadas | `/api/jornadas` | |
| Paradas | `/api/paradas` | |
| Rutas | `/api/rutas` | `PUT /{id}/activar` |
| Paradas de una ruta | `/api/ruta-paradas` | `GET ?rutaId=`; `PUT` cambia el orden; `DELETE` quita la parada |
| Asignación de estudiantes | `/api/asignaciones` | `GET ?rutaId=` / `?estudianteId=` |
| Pagos | `/api/pagos` | `GET /pendientes?mes=&anio=`; `DELETE` anula |
| Mantenimiento | `/api/mantenimientos` | `PUT /{id}/finalizar` (no hay DELETE) |
| Reportes / panel | `/api/dashboard` | |

## 5. Reglas del negocio y dónde están en el código

| Regla del acta | Dónde se aplica |
|---|---|
| Un vehículo no puede estar en dos rutas al mismo horario | `RutaService.validarRecursos` |
| Un piloto no puede conducir dos rutas a la vez | `RutaService.validarRecursos` |
| La licencia del piloto debe estar vigente | `RutaService.validarRecursos` |
| Vehículo en mantenimiento no se asigna a ruta activa | `RutaService.validarRecursos` y `MantenimientoService.registrar` |
| Una ruta debe tener al menos una parada | `RutaService.activar` y `RutaParadaService.quitar` |
| Un estudiante solo tiene una ruta activa por jornada | `AsignacionService.aplicar` |
| No superar la capacidad del vehículo | `AsignacionService.aplicar` y `RutaService.validarRecursos` |
| No borrar rutas con estudiantes: se desactivan | `RutaService.desactivar` (no existe borrado físico) |
| Pagos por mes y año, sin duplicados | `PagoService.aplicar` |
| Eliminación lógica en lugar de física | Todos los `DELETE` (marcan `estado = false`) |
| Búsqueda y filtrado (carné, vehículos disponibles, pagos pendientes) | `EstudianteService`, `VehiculoService`, `PagoService` |
| Dashboard (rutas activas, estudiantes con transporte, capacidad) | `DashboardService` |
| Contraseñas encriptadas | `UsuarioService` + `SeguridadConfig` (BCrypt) |

**Ciclo de vida de una ruta:** se crea *inactiva* → se le agregan paradas en `/api/ruta-paradas` →
se activa con `PUT /api/rutas/{id}/activar` (aquí se revisan todas las reglas) → ya se pueden asignar estudiantes.

---

## 6. Decisiones y diferencias con el UML y el SQL de las entregas

El UML y el script SQL no coincidían del todo. Se tomó el SQL como base y se ajustó con el acta:

| Tema | Decisión |
|---|---|
| `estado` | Es `Boolean` (true = activo) como en el UML; en el SQL era texto. |
| `Encargado.parentesco` | Se quitó de `Encargado` y queda solo en `EstudianteEncargado`, porque el parentesco depende de cada estudiante. |
| `Encargado.estado` | **Campo nuevo**, para poder desactivar en lugar de borrar (lo pide el acta). |
| `Piloto.fechaVencimientoLicencia` | **Campo nuevo.** Sin fecha de vencimiento no se puede cumplir "licencia vigente". Hay que agregarlo al diccionario de datos. |
| `Piloto.licencia` (SQL) | Se omitió: duplicaba `numero_licencia`. |
| `Vehiculo` | Lleva `marca` (UML y acta), `color` y `verificacion` (SQL). |
| `Mantenimiento.detalle` | Se usó `detalle` (SQL) en lugar de `descripcion` (UML). |
| Dinero | `BigDecimal` (no `double`) para `Pago.monto` y `Mantenimiento.costo`. |
| Llaves primarias | `Long id` en todas las entidades, como en `library-api`. |
| Pago `estado` | true = vigente, false = anulado. |
| Mantenimiento `estado` | true = en curso, false = finalizado. |
| Vehículo "disponible" | Activo y sin mantenimiento en curso. |
| Pago "pendiente" | Estudiante con transporte activo que no tiene pago vigente ese mes y año. |
| Front-end | Incluido en `src/main/resources/static/` (HTML + CSS + JavaScript, sin librerías). Spring lo sirve en `http://localhost:8080`. |

## 7. Qué se tomó de `library-api` y qué se mejoró

- **Igual:** misma organización en paquetes, entidades con getters/setters explícitos, DTOs con ids para las
  relaciones, inyección por constructor, MySQL con `ddl-auto=update`.
- **Mejorado:**
  - Errores con mensaje claro (404 / 400 / 401 / 409) en lugar de `orElseThrow()` sin texto.
  - `DELETE` desactiva en vez de borrar.
  - Validación de datos obligatorios y de reglas del negocio.
  - Contraseñas con BCrypt.
  - `pom.xml` corregido: en `library-api` aparecen las etiquetas `<title>` y `<country>` donde deberían ir
    `<name>` y `<description>`, y `spring.application.title` en lugar de `spring.application.name`.

## 8. Interfaz web (front-end)

```
src/main/resources/static/
├── index.html      ← login y estructura de la aplicación
├── css/estilos.css ← colores del boceto (menú azul marino) + amarillo de bus escolar
├── js/api.js       ← todas las llamadas a la API (fetch) y formatos de fecha/dinero
├── js/modulos.js   ← descripción de cada módulo: campos, columnas, acciones y permisos por rol
├── js/app.js       ← arma las pantallas: login, menú, CRUD genérico, panel y reportes
└── fonts/          ← fuente Barlow (funciona sin internet)
```

- Para agregar un campo a un formulario solo se edita `js/modulos.js`.
- El menú cambia según el rol (Administrador, Coordinador, Pagos, Estudiantes, Consulta).
  **Ojo:** esto solo esconde opciones; la API todavía no bloquea por rol.
- Si el front-end se abre desde otro servidor (Live Server, puerto 5500) funciona gracias a `config/CorsConfig.java`.

## 9. Pendientes / mejoras futuras

- **Control de acceso por rol:** hoy el login solo verifica usuario y contraseña; falta bloquear endpoints
  según el rol (Spring Security con tokens JWT o sesiones).
- **Pruebas automáticas** (`src/test`) de las reglas del negocio.
- Reglas no cubiertas por el acta y que se podrían agregar: impedir desactivar un vehículo, piloto o parada
  que esté en una ruta activa.
